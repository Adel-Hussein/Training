package Utility;

public class Constant {
	
	public static final String URL = "https://www.ballarddesigns.com/";
	
	
	public static final String Path_TestData = "//Users//adelhussein1//eclipse-workspace//VerifySearchTask//src//testData//";
	
	public static final String File_TestData = "searchSamples.xlsx";
	
	 public static final int Col_TestCaseName = 0; 
	 
	 public static final int Col_SearchKey = 1;
	 
	 public static final int Col_Result = 2;
	 

}
